#include "Gpio.h"
#include "Rcc.h"
#include "Std_Types.h"

int main() {

    uint8 portName = GPIO_A;
    uint8 pinNum = 0;
    uint8 pinMode = GPIO_OUTPUT;
    uint8 defaultState = 0;  // Push-Pull
	uint8 data; // To be written on the pin

	RCC_AHB1ENR |= (1 << 0);   // Enable clock for Port A (_should it be replaced with a function?_)

    Gpio_ConfigPin(portName, pinNum, pinMode, defaultState);   // Configure GPIO pin

    while (1) {

        data = HIGH;  // Turn on the led
        Gpio_WritePin(portName, pinNum, data);

        for (volatile unsigned long i = 0; i < 1500000; i++);  // Delay for 3 seconds

        data = LOW;  // Turn off the led
        Gpio_WritePin(portName, pinNum, data);

        for (volatile unsigned long i = 0; i < 1500000; i++);  // Delay for 3 seconds
    }

    return 0;
}
